<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define('TBL_MEDIA', 'ila_media');
define('TBL_TEMPLATE', 'ila_email_template');
define('TBL_BASIC_SETTINGS', 'ila_basic_settings');