					<div class="banner-section clearfix">
						<div class="container clearfix">
							<div class="banner-title">
								<h1><?php echo $this->lang->line('home_banner_text1');?> <span><?php echo $this->lang->line('home_banner_text2');?></span> <span><?php echo $this->lang->line('home_banner_text3');?></span> <span><?php echo $this->lang->line('home_banner_text4');?>!</span></h1>
							</div>
						</div>
						<a href="#inner-sections" class="next-section-arrow" id="next-section-arrow">Down arrow</a>
					</div>