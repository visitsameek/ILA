<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of MY_Model
 * @property CI_DB_query_builder $db QUERY BUILDER
 * @author SUCHANDAN
 */
class MY_Model extends CI_Model {

    //put your code here
    public function __construct() {
        parent::__construct();
    }

}
